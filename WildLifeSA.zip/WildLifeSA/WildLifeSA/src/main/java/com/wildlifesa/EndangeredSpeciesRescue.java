package com.wildlifesa;

/**
 * Represents a rescue case involving an endangered species.
 */
public class EndangeredSpeciesRescue extends RescueCase {

    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(String caseId, String animalName, String species,
                                   String rescueLocation, String assignedRanger,
                                   int rescueDays, double dailyCareCost,
                                   String conservationClassification,
                                   double securityCost,
                                   boolean specialistTeamRequired) {

        super(caseId, animalName, species, rescueLocation, assignedRanger,
                rescueDays, dailyCareCost);

        if (conservationClassification == null ||
                conservationClassification.isBlank()) {
            throw new IllegalArgumentException(
                    "Conservation classification cannot be blank.");
        }

        if (securityCost <= 0) {
            throw new IllegalArgumentException("Security cost must be greater than zero.");
        }

        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + securityCost;

        // Add R8 000 when a specialist team is required.
        if (specialistTeamRequired) {
            total += 8000;
        }

        return total;
    }

    @Override
    public String determinePriority() {
        return specialistTeamRequired ? "HIGH" : "MEDIUM";
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    public String getConservationClassification() {
        return conservationClassification;
    }

    public double getSecurityCost() {
        return securityCost;
    }

    public boolean isSpecialistTeamRequired() {
        return specialistTeamRequired;
    }
}
