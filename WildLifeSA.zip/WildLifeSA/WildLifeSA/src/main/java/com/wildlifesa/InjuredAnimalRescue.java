package com.wildlifesa;

/**
 * Represents a rescue case involving an injured animal.
 */
public class InjuredAnimalRescue extends RescueCase {

    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(String caseId, String animalName, String species,
                               String rescueLocation, String assignedRanger,
                               int rescueDays, double dailyCareCost,
                               String injuryDescription,
                               double veterinaryTreatmentCost,
                               boolean surgeryRequired) {

        super(caseId, animalName, species, rescueLocation, assignedRanger,
                rescueDays, dailyCareCost);

        if (injuryDescription == null || injuryDescription.isBlank()) {
            throw new IllegalArgumentException("Injury description cannot be blank.");
        }

        if (veterinaryTreatmentCost <= 0) {
            throw new IllegalArgumentException("Treatment cost must be greater than zero.");
        }

        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + veterinaryTreatmentCost;

        // Add R5 000 when surgery is required.
        if (surgeryRequired) {
            total += 5000;
        }

        return total;
    }

    @Override
    public String determinePriority() {
        return surgeryRequired ? "HIGH" : "MEDIUM";
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    public String getInjuryDescription() {
        return injuryDescription;
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }
}
