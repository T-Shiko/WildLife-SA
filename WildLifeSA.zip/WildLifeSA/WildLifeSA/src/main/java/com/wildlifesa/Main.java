package com.wildlifesa;

import java.util.Scanner;

/**
 * Main class for the console-based WildLife SA application.
 */
public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final RescueManager manager = new RescueManager();

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            displayMenu();
            int choice = readInt("Select an option: ");

            try {
                switch (choice) {
                    case 1 -> createInjuredRescue();
                    case 2 -> createOrphanedRescue();
                    case 3 -> createEndangeredRescue();
                    case 4 -> searchForCase();
                    case 5 -> updateStatus();
                    case 6 -> displayAllCases();
                    case 7 -> displayReport();
                    case 8 -> running = false;
                    default -> System.out.println("Invalid menu selection.");
                }
            } catch (IllegalArgumentException exception) {
                // Invalid input should not crash the application.
                System.out.println("Error: " + exception.getMessage());
            }
        }

        System.out.println("Thank you for using WildLife SA.");
    }

    private static void displayMenu() {
        System.out.println("\n========== WILDLIFE SA MENU ==========");
        System.out.println("1. Add injured animal rescue");
        System.out.println("2. Add orphaned animal rescue");
        System.out.println("3. Add endangered species rescue");
        System.out.println("4. Search for rescue case");
        System.out.println("5. Update rescue status");
        System.out.println("6. Display all rescue cases");
        System.out.println("7. Generate rescue report");
        System.out.println("8. Exit");
        System.out.println("======================================");
    }

    private static void createInjuredRescue() {
        String id = readText("Case ID: ");
        String name = readText("Animal name: ");
        String species = readText("Species: ");
        String location = readText("Rescue location: ");
        String ranger = readText("Assigned ranger: ");
        int days = readInt("Number of rescue days: ");
        double dailyCost = readDouble("Daily care cost: ");
        String injury = readText("Injury description: ");
        double treatmentCost = readDouble("Veterinary treatment cost: ");
        boolean surgery = readBoolean("Is surgery required? (y/n): ");

        RescueCase rescue = new InjuredAnimalRescue(
                id, name, species, location, ranger, days, dailyCost,
                injury, treatmentCost, surgery
        );

        manager.addRescueCase(rescue);
        System.out.println("Injured animal rescue added successfully.");
    }

    private static void createOrphanedRescue() {
        String id = readText("Case ID: ");
        String name = readText("Animal name: ");
        String species = readText("Species: ");
        String location = readText("Rescue location: ");
        String ranger = readText("Assigned ranger: ");
        int days = readInt("Number of rescue days: ");
        double dailyCost = readDouble("Daily care cost: ");
        int age = readInt("Estimated age in months: ");
        double feedingCost = readDouble("Feeding cost: ");
        boolean foster = readBoolean("Is foster care required? (y/n): ");

        RescueCase rescue = new OrphanedAnimalRescue(
                id, name, species, location, ranger, days, dailyCost,
                age, feedingCost, foster
        );

        manager.addRescueCase(rescue);
        System.out.println("Orphaned animal rescue added successfully.");
    }

    private static void createEndangeredRescue() {
        String id = readText("Case ID: ");
        String name = readText("Animal name: ");
        String species = readText("Species: ");
        String location = readText("Rescue location: ");
        String ranger = readText("Assigned ranger: ");
        int days = readInt("Number of rescue days: ");
        double dailyCost = readDouble("Daily care cost: ");
        String classification = readText("Conservation classification: ");
        double securityCost = readDouble("Security cost: ");
        boolean specialist = readBoolean("Is a specialist team required? (y/n): ");

        RescueCase rescue = new EndangeredSpeciesRescue(
                id, name, species, location, ranger, days, dailyCost,
                classification, securityCost, specialist
        );

        manager.addRescueCase(rescue);
        System.out.println("Endangered species rescue added successfully.");
    }

    private static void searchForCase() {
        String id = readText("Enter Case ID to search: ");
        RescueCase rescue = manager.findById(id);

        if (rescue == null) {
            System.out.println("No rescue case found.");
        } else {
            System.out.println(rescue.generateSummary());
        }
    }

    private static void updateStatus() {
        String id = readText("Enter Case ID: ");
        System.out.println("1. Start rescue");
        System.out.println("2. Complete rescue");

        int choice = readInt("Choose status update: ");
        boolean updated;

        if (choice == 1) {
            updated = manager.updateStatus(id, RescueStatus.IN_PROGRESS);
        } else if (choice == 2) {
            updated = manager.updateStatus(id, RescueStatus.COMPLETED);
        } else {
            System.out.println("Invalid status option.");
            return;
        }

        System.out.println(updated
                ? "Status updated successfully."
                : "Could not update status.");
    }

    private static void displayAllCases() {
        if (manager.getAllCases().isEmpty()) {
            System.out.println("No rescue cases have been stored.");
            return;
        }

        for (RescueCase rescue : manager.getAllCases()) {
            System.out.println(rescue.generateSummary());
            System.out.println("-----------------------------------");
        }
    }

    private static void displayReport() {
        System.out.println(manager.generateReport());
    }

    private static String readText(String message) {
        System.out.print(message);
        String value = scanner.nextLine().trim();

        if (value.isBlank()) {
            throw new IllegalArgumentException("Text input cannot be blank.");
        }

        return value;
    }

    private static int readInt(String message) {
        System.out.print(message);

        try {
            int value = Integer.parseInt(scanner.nextLine().trim());

            if (value <= 0) {
                throw new IllegalArgumentException("Number must be greater than zero.");
            }

            return value;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException("Please enter a valid whole number.");
        }
    }

    private static double readDouble(String message) {
        System.out.print(message);

        try {
            double value = Double.parseDouble(scanner.nextLine().trim());

            if (value <= 0) {
                throw new IllegalArgumentException("Number must be greater than zero.");
            }

            return value;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException("Please enter a valid number.");
        }
    }

    private static boolean readBoolean(String message) {
        System.out.print(message);
        String value = scanner.nextLine().trim().toLowerCase();

        if (value.equals("y")) {
            return true;
        }

        if (value.equals("n")) {
            return false;
        }

        throw new IllegalArgumentException("Please enter y or n.");
    }
}
