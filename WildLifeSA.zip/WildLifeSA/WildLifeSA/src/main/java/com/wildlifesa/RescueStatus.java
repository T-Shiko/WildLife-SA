package com.wildlifesa;

/**
 * Stores the possible statuses of a rescue case.
 */
public enum RescueStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
