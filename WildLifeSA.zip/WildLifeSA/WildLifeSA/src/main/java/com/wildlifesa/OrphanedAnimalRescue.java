package com.wildlifesa;

/**
 * Represents a rescue case involving an orphaned animal.
 */
public class OrphanedAnimalRescue extends RescueCase {

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(String caseId, String animalName, String species,
                                String rescueLocation, String assignedRanger,
                                int rescueDays, double dailyCareCost,
                                int estimatedAgeMonths, double feedingCost,
                                boolean fosterCareRequired) {

        super(caseId, animalName, species, rescueLocation, assignedRanger,
                rescueDays, dailyCareCost);

        if (estimatedAgeMonths <= 0 || feedingCost <= 0) {
            throw new IllegalArgumentException(
                    "Age and feeding cost must be greater than zero.");
        }

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + feedingCost;

        // Add R2 500 when foster care is required.
        if (fosterCareRequired) {
            total += 2500;
        }

        return total;
    }

    @Override
    public String determinePriority() {
        return estimatedAgeMonths <= 6 ? "HIGH" : "MEDIUM";
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }
}
