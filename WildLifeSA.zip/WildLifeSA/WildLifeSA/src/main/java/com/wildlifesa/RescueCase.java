package com.wildlifesa;

/**
 * Abstract parent class containing information shared by all rescue cases.
 * It also implements the RescueOperations interface.
 */
public abstract class RescueCase implements RescueOperations {

    // Private fields demonstrate encapsulation.
    private String caseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int rescueDays;
    private double dailyCareCost;
    private RescueStatus status;

    /**
     * Constructor used to initialise common rescue case information.
     */
    public RescueCase(String caseId, String animalName, String species,
                      String rescueLocation, String assignedRanger,
                      int rescueDays, double dailyCareCost) {

        if (caseId == null || caseId.isBlank()) {
            throw new IllegalArgumentException("Case ID cannot be blank.");
        }

        if (species == null || species.isBlank()) {
            throw new IllegalArgumentException("Species cannot be blank.");
        }

        if (rescueLocation == null || rescueLocation.isBlank()) {
            throw new IllegalArgumentException("Rescue location cannot be blank.");
        }

        if (assignedRanger == null || assignedRanger.isBlank()) {
            throw new IllegalArgumentException("Assigned ranger cannot be blank.");
        }

        if (rescueDays <= 0 || dailyCareCost <= 0) {
            throw new IllegalArgumentException(
                    "Rescue days and daily care cost must be greater than zero.");
        }

        this.caseId = caseId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.status = RescueStatus.PENDING;
    }

    // Getters allow controlled access to private fields.
    public String getCaseId() {
        return caseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getRescueDays() {
        return rescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public RescueStatus getStatus() {
        return status;
    }

    // Protected setter allows subclasses to access status safely.
    protected void setStatus(RescueStatus status) {
        this.status = status;
    }

    // Calculates the common care cost for every rescue case.
    public double calculateBaseCost() {
        return rescueDays * dailyCareCost;
    }

    // Every subclass must provide its own total cost calculation.
    public abstract double calculateTotalCost();

    // Every subclass must provide its own priority calculation.
    public abstract String determinePriority();

    // Returns the name of the specific rescue type.
    public abstract String getRescueType();

    @Override
    public void startRescue() {
        setStatus(RescueStatus.IN_PROGRESS);
    }

    @Override
    public void completeRescue() {
        setStatus(RescueStatus.COMPLETED);
    }

    @Override
    public String generateSummary() {
        return String.format(
                "Case ID: %s%nRescue Type: %s%nSpecies: %s%nRanger: %s%n" +
                "Priority: %s%nStatus: %s%nTotal Cost: R%.2f",
                caseId,
                getRescueType(),
                species,
                assignedRanger,
                determinePriority(),
                status,
                calculateTotalCost()
        );
    }
}
