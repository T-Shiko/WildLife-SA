package com.wildlifesa;

import java.util.ArrayList;
import java.util.List;

/**
 * Manages multiple rescue cases using an ArrayList.
 */
public class RescueManager {

    // ArrayList stores all rescue cases in memory.
    private final ArrayList<RescueCase> rescueCases = new ArrayList<>();

    /**
     * Adds a rescue case if its ID is unique.
     */
    public void addRescueCase(RescueCase rescueCase) {
        if (findById(rescueCase.getCaseId()) != null) {
            throw new IllegalArgumentException("Rescue Case ID already exists.");
        }

        rescueCases.add(rescueCase);
    }

    /**
     * Searches for a rescue case by its ID.
     */
    public RescueCase findById(String caseId) {
        for (RescueCase rescueCase : rescueCases) {
            if (rescueCase.getCaseId().equalsIgnoreCase(caseId)) {
                return rescueCase;
            }
        }

        return null;
    }

    /**
     * Returns all stored rescue cases.
     */
    public List<RescueCase> getAllCases() {
        return new ArrayList<>(rescueCases);
    }

    /**
     * Updates the status of a rescue case.
     */
    public boolean updateStatus(String caseId, RescueStatus newStatus) {
        RescueCase rescueCase = findById(caseId);

        if (rescueCase == null) {
            return false;
        }

        if (newStatus == RescueStatus.IN_PROGRESS) {
            rescueCase.startRescue();
        } else if (newStatus == RescueStatus.COMPLETED) {
            rescueCase.completeRescue();
        } else {
            // A new case normally starts as PENDING.
            return false;
        }

        return true;
    }

    /**
     * Prints a report containing all rescue cases and total costs.
     */
    public String generateReport() {
        StringBuilder report = new StringBuilder();
        double totalCost = 0;

        report.append("\n========== WILDLIFE SA RESCUE REPORT ==========\n");

        for (RescueCase rescueCase : rescueCases) {
            report.append("-----------------------------------------------\n");
            report.append("Case ID: ").append(rescueCase.getCaseId()).append("\n");
            report.append("Rescue Type: ").append(rescueCase.getRescueType()).append("\n");
            report.append("Species: ").append(rescueCase.getSpecies()).append("\n");
            report.append("Location: ").append(rescueCase.getRescueLocation()).append("\n");
            report.append("Ranger: ").append(rescueCase.getAssignedRanger()).append("\n");
            report.append("Priority: ").append(rescueCase.determinePriority()).append("\n");
            report.append("Status: ").append(rescueCase.getStatus()).append("\n");
            report.append(String.format("Total Cost: R%.2f%n",
                    rescueCase.calculateTotalCost()));

            totalCost += rescueCase.calculateTotalCost();
        }

        report.append("-----------------------------------------------\n");
        report.append("Total Cases: ").append(rescueCases.size()).append("\n");
        report.append(String.format("Total Estimated Cost: R%.2f%n", totalCost));
        report.append("===============================================\n");

        return report.toString();
    }
}
