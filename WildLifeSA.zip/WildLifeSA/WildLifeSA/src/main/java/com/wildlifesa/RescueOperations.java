package com.wildlifesa;

/**
 * Interface containing the operations that every rescue type must support.
 */
public interface RescueOperations {

    // Starts a rescue operation.
    void startRescue();

    // Completes a rescue operation.
    void completeRescue();

    // Generates a summary of the rescue.
    String generateSummary();
}
