package com.wildlifesa;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 tests for the core functionality of the application.
 */
public class RescueCaseTest {

    @Test
    void injuredRescueCostIncludesSurgeryFee() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "I001", "Leo", "Lion", "Cape Town", "Ranger A",
                2, 1000, "Broken leg", 3000, true
        );

        // Base cost = 2 * 1000 = 2000.
        // Total = 2000 + 3000 + 5000 surgery fee = 10000.
        assertEquals(10000, rescue.calculateTotalCost());
    }

    @Test
    void orphanedRescueCostIncludesFosterCareFee() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "O001", "Milo", "Elephant", "Durban", "Ranger B",
                3, 1000, 4, 1500, true
        );

        // Base cost = 3000.
        // Total = 3000 + 1500 + 2500 foster fee = 7000.
        assertEquals(7000, rescue.calculateTotalCost());
    }

    @Test
    void endangeredRescueCostIncludesSpecialistFee() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "E001", "Zuri", "Rhino", "Pretoria", "Ranger C",
                2, 1000, "Critically Endangered", 2000, true
        );

        // Base cost = 2000.
        // Total = 2000 + 2000 + 8000 specialist fee = 12000.
        assertEquals(12000, rescue.calculateTotalCost());
    }

    @Test
    void priorityIsCalculatedCorrectly() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "I002", "Kito", "Leopard", "Limpopo", "Ranger D",
                1, 500, "Severe injury", 1000, true
        );

        assertEquals("HIGH", rescue.determinePriority());
    }

    @Test
    void statusChangesWhenRescueStartsAndCompletes() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "I003", "Nala", "Lion", "Free State", "Ranger E",
                1, 500, "Minor injury", 1000, false
        );

        assertEquals(RescueStatus.PENDING, rescue.getStatus());

        rescue.startRescue();
        assertEquals(RescueStatus.IN_PROGRESS, rescue.getStatus());

        rescue.completeRescue();
        assertEquals(RescueStatus.COMPLETED, rescue.getStatus());
    }

    @Test
    void existingRescueCaseCanBeFound() {
        RescueManager manager = new RescueManager();

        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "I004", "Simba", "Lion", "Johannesburg", "Ranger F",
                2, 500, "Injury", 1000, false
        );

        manager.addRescueCase(rescue);

        assertNotNull(manager.findById("I004"));
        assertEquals("Simba", manager.findById("I004").getAnimalName());
    }

    @Test
    void duplicateCaseIdsArePrevented() {
        RescueManager manager = new RescueManager();

        InjuredAnimalRescue first = new InjuredAnimalRescue(
                "D001", "Animal One", "Lion", "Area One", "Ranger One",
                1, 100, "Injury", 100, false
        );

        InjuredAnimalRescue second = new InjuredAnimalRescue(
                "D001", "Animal Two", "Tiger", "Area Two", "Ranger Two",
                1, 100, "Injury", 100, false
        );

        manager.addRescueCase(first);

        // The second case uses the same ID, so an exception is expected.
        assertThrows(IllegalArgumentException.class,
                () -> manager.addRescueCase(second));
    }
}
